<div class="contact-feedback">
    <h2>Your Comments Have Been Received!</h2>
    <p>Thanks for the input!</p>
    <p>We'll respond via email within 48 hours, if you requested information.</p>
</div> 